The Custom Search Workshop Starter! Click Fork on this Replit and follow the instructions from the workshop. 

Disclaimer: Do not make your API key public or exceed 100 queries per day!

Happy Hacking!